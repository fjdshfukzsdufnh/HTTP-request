﻿using System;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

class Program
{
    static async Task Main(string[] args)
    {
        var requestData = new
        {
            N = 4,
            Dist = new double[][]
            {
                new double[] { 0, 10, 15, 20 },
                new double[] { 10, 0, 35, 25 },
                new double[] { 15, 35, 0, 30 },
                new double[] { 20, 25, 30, 0 }
            }
        };

        string url = "http://localhost:5155/api/tsp/solve"; 

        using (HttpClient client = new HttpClient())
        {
            string jsonData = JsonSerializer.Serialize(requestData);

            HttpContent content = new StringContent(jsonData, Encoding.UTF8, "application/json");

            HttpResponseMessage response = await client.PostAsync(url, content);

            if (response.IsSuccessStatusCode)
            {
                string responseBody = await response.Content.ReadAsStringAsync();
                var result = JsonSerializer.Deserialize<ResponseType>(responseBody);
                Console.WriteLine($"Минимальное расстояние: {result.MinDistance}");
            }
            else
            {
                Console.WriteLine($"Ошибка: {response.StatusCode}");
            }
        }
    }

    class ResponseType
    {
        public double MinDistance { get; set; }
    }
}
